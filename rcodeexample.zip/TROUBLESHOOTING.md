# Troubleshooting: "Error: object 'shiny' not found"

This error means the Shiny package is not properly installed or accessible in R Portable.

## Quick Fix (Recommended)

### Step 1: Run Diagnostic
Open Command Prompt in your portable app folder and run:
```
R-Portable\bin\Rscript.exe diagnose_setup.R
```

This will identify the problem.

### Step 2: Install Packages
Run the automated installer:
```
R-Portable\bin\Rscript.exe install_packages.R
```

### Step 3: Test Again
Double-click `run.bat` to test your app.

## Manual Fix

### Option 1: Install Shiny via Command Line
1. Open Command Prompt
2. Navigate to your portable app folder
3. Run:
   ```
   R-Portable\bin\Rscript.exe -e "install.packages('shiny', repos='https://cran.rstudio.com/')"
   ```
4. Wait for installation to complete
5. Try running your app again

### Option 2: Install via R Console
1. Double-click: `R-Portable\bin\R.exe`
2. In the R console, type:
   ```r
   install.packages('shiny')
   ```
3. Press Enter and wait for installation
4. Test by typing: `library(shiny)`
5. If successful, close R with: `q()` (don't save workspace)
6. Try running your app again

## Common Causes and Solutions

### Cause 1: Rprofile.site Missing or Incorrect
**Symptom:** Multiple library paths shown in diagnostic

**Solution:**
1. Go to: `R-Portable\etc\`
2. Open or create file: `Rprofile.site`
3. Make sure it contains ONLY this line:
   ```r
   .libPaths(.Library)
   ```
4. Save and close
5. Restart R and reinstall packages

### Cause 2: Packages Installed in System R Instead of Portable
**Symptom:** You have R installed on your system, and packages went there

**Solution:**
1. Verify Rprofile.site is correct (see Cause 1)
2. Delete the library folder: `R-Portable\library\`
3. Recreate it: Create an empty folder named `library`
4. Run the install_packages.R script again

### Cause 3: Incomplete Installation
**Symptom:** Installation errors or warnings during package install

**Solution:**
1. Check internet connection
2. Try installing one package at a time:
   ```r
   install.packages('shiny')
   ```
3. Look for specific error messages
4. If compilation errors occur, you may need Rtools (but this is rare for binary packages)

### Cause 4: Corrupted Package Installation
**Symptom:** Package installed but won't load

**Solution:**
1. Remove the corrupted package:
   ```r
   remove.packages('shiny')
   ```
2. Reinstall:
   ```r
   install.packages('shiny')
   ```

## Verification Steps

After fixing, verify everything works:

### Test 1: Check Library Path
```
R-Portable\bin\Rscript.exe -e ".libPaths()"
```
Should show only ONE path (to R-Portable\library)

### Test 2: Check Shiny Installation
```
R-Portable\bin\Rscript.exe -e "library(shiny); packageVersion('shiny')"
```
Should print Shiny version number without errors

### Test 3: Run Diagnostic
```
R-Portable\bin\Rscript.exe diagnose_setup.R
```
Should show all checks passing

### Test 4: Run Your App
```
run.bat
```
Should launch your app in the browser

## Still Not Working?

If you're still having issues:

1. **Check ShinyApp.log** - Look for specific error messages
   
2. **Verify file structure:**
   ```
   YourFolder/
   ├── R-Portable/
   │   ├── bin/
   │   │   ├── R.exe
   │   │   └── Rscript.exe
   │   ├── etc/
   │   │   └── Rprofile.site
   │   └── library/
   │       └── shiny/
   ├── soar_world/
   │   └── app.R (or server.R/ui.R)
   ├── runShinyApp.R
   └── run.bat
   ```

3. **Try a fresh installation:**
   - Delete the R-Portable folder
   - Follow the setup guide from scratch
   - Install packages using install_packages.R

4. **Check Windows permissions:**
   - Make sure you have write permissions to the folder
   - Try running as administrator (right-click run.bat → Run as administrator)

5. **Check antivirus:**
   - Some antivirus software may block R scripts
   - Add the folder to your antivirus exceptions

## Getting More Help

When asking for help, include:
- Contents of `ShinyApp.log`
- Output from `diagnose_setup.R`
- Your Windows version
- Whether you have R installed on your system
- Output from running:
  ```
  R-Portable\bin\Rscript.exe -e "sessionInfo()"
  ```

## Quick Reference: All Commands

**Diagnose:**
```
R-Portable\bin\Rscript.exe diagnose_setup.R
```

**Install packages:**
```
R-Portable\bin\Rscript.exe install_packages.R
```

**Install single package:**
```
R-Portable\bin\Rscript.exe -e "install.packages('packagename')"
```

**Test package loading:**
```
R-Portable\bin\Rscript.exe -e "library(packagename)"
```

**Check library paths:**
```
R-Portable\bin\Rscript.exe -e ".libPaths()"
```
