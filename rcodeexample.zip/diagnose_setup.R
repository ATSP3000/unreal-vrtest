# diagnose_setup.R
# Run this script to diagnose R Portable setup issues
# Usage: R-Portable\bin\Rscript.exe diagnose_setup.R

cat("\n========================================\n")
cat("R Portable Setup Diagnostic\n")
cat("========================================\n\n")

# Check R version
cat("1. R Version:\n")
cat("   ", R.version.string, "\n\n")

# Check library paths
cat("2. Library Paths:\n")
lib_paths <- .libPaths()
for (i in seq_along(lib_paths)) {
  cat("   [", i, "] ", lib_paths[i], "\n", sep = "")
  cat("       Exists: ", dir.exists(lib_paths[i]), "\n", sep = "")
  cat("       Writable: ", file.access(lib_paths[i], mode = 2) == 0, "\n", sep = "")
}
cat("\n")

# Check if library path is local (portable)
cat("3. Portability Check:\n")
if (length(lib_paths) == 1) {
  cat("   ✓ Good: Only one library path (portable setup)\n")
} else {
  cat("   ✗ Warning: Multiple library paths detected\n")
  cat("   This may indicate R is using system libraries\n")
  cat("   Check your Rprofile.site file\n")
}
cat("\n")

# Check for Rprofile.site
cat("4. Rprofile.site Check:\n")
rprofile_path <- file.path(R.home("etc"), "Rprofile.site")
cat("   Path: ", rprofile_path, "\n", sep = "")
cat("   Exists: ", file.exists(rprofile_path), "\n", sep = "")
if (file.exists(rprofile_path)) {
  cat("   Contents:\n")
  profile_content <- readLines(rprofile_path)
  for (line in profile_content) {
    cat("      ", line, "\n", sep = "")
  }
}
cat("\n")

# Check installed packages
cat("5. Installed Packages:\n")
installed <- installed.packages()[, "Package"]
cat("   Total packages installed: ", length(installed), "\n\n", sep = "")

# Check for essential packages
essential <- c("shiny", "htmltools", "httpuv", "jsonlite", "xtable", "digest", 
               "R6", "sourcetools", "later", "promises", "mime", "rlang")

cat("6. Essential Package Check:\n")
all_present <- TRUE
for (pkg in essential) {
  is_installed <- pkg %in% installed
  status <- if (is_installed) "✓" else "✗"
  cat("   ", status, " ", pkg, "\n", sep = "")
  if (!is_installed) all_present <- FALSE
}
cat("\n")

# Try loading shiny
cat("7. Loading Shiny Test:\n")
shiny_load_result <- tryCatch({
  library(shiny)
  cat("   ✓ Success: Shiny loaded successfully\n")
  cat("   Shiny version: ", as.character(packageVersion("shiny")), "\n", sep = "")
  TRUE
}, error = function(e) {
  cat("   ✗ Error loading shiny:\n")
  cat("   ", e$message, "\n", sep = "")
  FALSE
})
cat("\n")

# Overall assessment
cat("========================================\n")
cat("Overall Assessment:\n")
cat("========================================\n")

if (length(lib_paths) == 1 && all_present && shiny_load_result) {
  cat("✓ Your R Portable setup looks good!\n")
  cat("  If you're still having issues, check:\n")
  cat("  - That runShinyApp.R is in the correct location\n")
  cat("  - That your app files are in ./soar_world/\n")
} else {
  cat("✗ Issues detected. Please fix the following:\n\n")
  
  if (length(lib_paths) > 1) {
    cat("1. Multiple library paths detected:\n")
    cat("   - Edit: R-Portable/etc/Rprofile.site\n")
    cat("   - Ensure it contains only: .libPaths(.Library)\n")
    cat("   - Restart R after making changes\n\n")
  }
  
  if (!all_present) {
    cat("2. Missing essential packages:\n")
    cat("   Run the install_packages.R script to install them\n\n")
  }
  
  if (!shiny_load_result) {
    cat("3. Cannot load shiny package:\n")
    cat("   - Reinstall shiny: install.packages('shiny')\n")
    cat("   - Check for error messages during installation\n\n")
  }
}

cat("\n========================================\n")
cat("Diagnostic Complete\n")
cat("========================================\n")
