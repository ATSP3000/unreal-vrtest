# install_packages.R
# Automated package installation script for R Portable
# Run this in R Portable: R-Portable\bin\Rscript.exe install_packages.R

cat("\n========================================\n")
cat("R Portable Package Installer\n")
cat("========================================\n\n")

# Verify library path is portable
cat("Checking library path...\n")
lib_paths <- .libPaths()
cat("Library path:", lib_paths[1], "\n\n")

if (length(lib_paths) > 1) {
  warning("Multiple library paths detected. This may not be a proper portable setup.")
  cat("Continuing with installation to:", lib_paths[1], "\n\n")
}

# Essential packages for Shiny
essential_packages <- c(
  "shiny",
  "htmltools",
  "httpuv",
  "jsonlite",
  "xtable",
  "digest",
  "R6",
  "sourcetools",
  "later",
  "promises",
  "mime",
  "rlang",
  "fastmap",
  "ellipsis",
  "lifecycle",
  "vctrs",
  "glue",
  "magrittr",
  "cli",
  "withr"
)

# Add your additional packages here
# Edit this list based on what your soar_world app needs
additional_packages <- c(
  # Uncomment and add packages as needed:
  # "ggplot2",
  # "dplyr",
  # "tidyr",
  # "plotly",
  # "leaflet",
  # "DT",
  # "shinydashboard",
  # "shinyWidgets"
)

# Combine all packages
all_packages <- unique(c(essential_packages, additional_packages))

cat("Packages to install:", length(all_packages), "\n")
cat("----------------------------------------\n")
for (pkg in all_packages) {
  cat("  -", pkg, "\n")
}
cat("----------------------------------------\n\n")

# Check which packages are already installed
installed <- installed.packages()[, "Package"]
to_install <- setdiff(all_packages, installed)

if (length(to_install) == 0) {
  cat("✓ All packages are already installed!\n\n")
} else {
  cat("Installing", length(to_install), "packages...\n\n")
  
  # Install packages one by one for better error tracking
  success_count <- 0
  fail_count <- 0
  failed_packages <- c()
  
  for (pkg in to_install) {
    cat("Installing:", pkg, "... ")
    
    result <- tryCatch({
      install.packages(pkg, quiet = TRUE, repos = "https://cran.rstudio.com/")
      cat("✓ Success\n")
      success_count <- success_count + 1
      TRUE
    }, error = function(e) {
      cat("✗ Failed\n")
      cat("   Error:", e$message, "\n")
      fail_count <- fail_count + 1
      failed_packages <<- c(failed_packages, pkg)
      FALSE
    }, warning = function(w) {
      cat("⚠ Warning\n")
      cat("   Warning:", w$message, "\n")
      success_count <- success_count + 1
      TRUE
    })
    
    # Small delay to avoid overwhelming CRAN
    Sys.sleep(0.5)
  }
  
  cat("\n========================================\n")
  cat("Installation Summary:\n")
  cat("========================================\n")
  cat("Successfully installed:", success_count, "\n")
  cat("Failed:", fail_count, "\n")
  
  if (fail_count > 0) {
    cat("\nFailed packages:\n")
    for (pkg in failed_packages) {
      cat("  -", pkg, "\n")
    }
    cat("\nTo manually install failed packages, open R and run:\n")
    cat("  install.packages(c('", paste(failed_packages, collapse = "', '"), "'))\n", sep = "")
  }
}

# Test loading shiny
cat("\n========================================\n")
cat("Testing Shiny Installation:\n")
cat("========================================\n")

shiny_test <- tryCatch({
  library(shiny)
  cat("✓ Success! Shiny loaded successfully\n")
  cat("  Version:", as.character(packageVersion("shiny")), "\n")
  TRUE
}, error = function(e) {
  cat("✗ Error loading shiny:\n")
  cat("  ", e$message, "\n")
  FALSE
})

cat("\n========================================\n")
if (shiny_test) {
  cat("✓ Installation Complete!\n")
  cat("You can now run your Shiny app.\n")
} else {
  cat("✗ Installation had issues.\n")
  cat("Please review the errors above.\n")
}
cat("========================================\n\n")
