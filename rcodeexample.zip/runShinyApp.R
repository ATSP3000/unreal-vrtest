# runShinyApp.R
# Launcher script for SOAR World portable Shiny app

cat("\n========================================\n")
cat("SOAR World App Launcher\n")
cat("========================================\n\n")

# Display library paths for debugging
cat('Library paths:\n')
lib_paths <- .libPaths()
for (path in lib_paths) {
  cat('  - ', path, '\n', sep = '')
}
cat('\n')

# Check if we're in the right directory
if (!dir.exists('./soar_world/')) {
  stop("Error: Cannot find './soar_world/' directory.\n",
       "Make sure you're running this from the correct location.\n",
       "Expected structure:\n",
       "  - runShinyApp.R (this file)\n",
       "  - soar_world/ (your app folder)\n",
       "  - R-Portable/ (R installation)")
}

cat("✓ Found soar_world directory\n\n")

# Try to load shiny
cat("Loading Shiny package...\n")
tryCatch({
  library(shiny)
  cat("✓ Shiny loaded successfully (version ", as.character(packageVersion("shiny")), ")\n\n", sep = "")
}, error = function(e) {
  cat("\n✗ ERROR: Cannot load Shiny package!\n")
  cat("Error message:", e$message, "\n\n")
  cat("This usually means Shiny is not installed in R Portable.\n")
  cat("To fix this:\n")
  cat("  1. Open: R-Portable\\bin\\R.exe\n")
  cat("  2. Run: install.packages('shiny')\n")
  cat("  3. Or run the install_packages.R script\n\n")
  stop("Shiny package not available")
})

# Load any additional required packages
# Uncomment and add your packages here:
# cat("Loading additional packages...\n")
# required_packages <- c("ggplot2", "dplyr")
# for (pkg in required_packages) {
#   tryCatch({
#     library(pkg, character.only = TRUE)
#     cat("✓ Loaded:", pkg, "\n")
#   }, error = function(e) {
#     cat("✗ Failed to load:", pkg, "\n")
#     cat("  Error:", e$message, "\n")
#   })
# }
# cat("\n")

# Launch the Shiny app
cat("Starting SOAR World application...\n")
cat("The app will open in your browser shortly.\n")
cat("To stop the app, close this window or press Ctrl+C\n")
cat("========================================\n\n")

tryCatch({
  shiny::runApp(
    appDir = './soar_world/',
    launch.browser = TRUE,
    port = 8888,
    quiet = FALSE
  )
}, error = function(e) {
  cat("\n✗ ERROR: Failed to start the app!\n")
  cat("Error message:", e$message, "\n\n")
  cat("Check that:\n")
  cat("  1. All app files are in ./soar_world/\n")
  cat("  2. You have app.R or server.R/ui.R in the soar_world folder\n")
  cat("  3. All required packages are installed\n\n")
  stop("Failed to launch Shiny app")
})
