# R Portable Shiny App - Files Overview

This package contains everything you need to create and troubleshoot a portable version of your SOAR World Shiny app.

## 📁 Files Included

### Documentation
| File | Purpose |
|------|---------|
| **QUICK_FIX.md** | ⭐ Start here if you have the "shiny not found" error |
| **Portable_Shiny_App_Guide.md** | Complete setup guide from start to finish |
| **TROUBLESHOOTING.md** | Detailed troubleshooting for all common issues |
| **SETUP_CHECKLIST.md** | Step-by-step checklist to stay organized |
| **README_FOR_USERS.txt** | Instructions for end users (include in final package) |

### Scripts
| File | Purpose |
|------|---------|
| **runShinyApp.R** | Main launcher script (launches your app) |
| **diagnose_setup.R** | Diagnostic script (checks R Portable setup) |
| **install_packages.R** | Automated package installer |
| **detect_packages.R** | Finds packages your app needs |

### Batch Files (Windows)
| File | Purpose |
|------|---------|
| **run.bat** | ⭐ Users double-click this to run the app (shows console) |
| **run.vbs** | Alternative launcher (hides console window) |
| **diagnose.bat** | Run diagnostics (double-click to check setup) |
| **install.bat** | Install packages (double-click to install Shiny, etc.) |

### Support Files
| File | Purpose |
|------|---------|
| **packages_required.txt** | Template to track required packages |

## 🚀 Quick Start

### If This Is Your First Time:
1. Read **Portable_Shiny_App_Guide.md**
2. Follow the guide step by step
3. Use **SETUP_CHECKLIST.md** to track progress

### If You Have "shiny not found" Error:
1. Read **QUICK_FIX.md** ⭐
2. Run **diagnose.bat**
3. Run **install.bat**
4. Try **run.bat** again

### If You're Having Other Issues:
1. Read **TROUBLESHOOTING.md**
2. Run **diagnose.bat** to identify the problem
3. Follow the suggested solutions

## 📦 What Goes in Your Final Package

When you distribute your app to users, include:

```
PortableShinyApp/
├── R-Portable/              (entire folder)
├── soar_world/              (your app)
├── runShinyApp.R
├── run.bat                  ⭐ Users click this
├── run.vbs                  (alternative)
├── README_FOR_USERS.txt     ⭐ Users read this
└── ShinyApp.log             (created after first run)
```

**Don't include** these development files:
- diagnose_setup.R
- install_packages.R
- detect_packages.R
- diagnose.bat
- install.bat
- All the .md documentation files

## 🔧 File Usage by Role

### For Developers (You):
**Setting up:**
1. Portable_Shiny_App_Guide.md
2. detect_packages.R (find required packages)
3. SETUP_CHECKLIST.md (track progress)

**Installing packages:**
1. install.bat (automated)
2. install_packages.R (the script install.bat runs)

**Troubleshooting:**
1. diagnose.bat (quick check)
2. diagnose_setup.R (the script diagnose.bat runs)
3. TROUBLESHOOTING.md (detailed solutions)
4. QUICK_FIX.md (common issues)

### For End Users:
**To use:**
1. README_FOR_USERS.txt (instructions)
2. run.bat or run.vbs (launch app)

**If problems:**
1. ShinyApp.log (check errors)

## 📋 Typical Workflow

### First Time Setup:
```
1. Read Portable_Shiny_App_Guide.md
2. Download/install R Portable
3. Create Rprofile.site
4. Run: detect_packages.R (in your dev environment)
5. Run: install.bat (in R Portable)
6. Copy soar_world app files
7. Test with run.bat
8. Package for distribution
```

### If Setup Fails:
```
1. Run: diagnose.bat
2. Review output
3. Read: QUICK_FIX.md or TROUBLESHOOTING.md
4. Fix issues
5. Run: install.bat again
6. Test with run.bat
```

### Before Distribution:
```
1. Test on your machine
2. Test on a clean machine (no R installed)
3. Include only user files (see above)
4. Create ZIP or installer
5. Write simple instructions
```

## 🎯 Most Common Issues

| Issue | Quick Fix |
|-------|-----------|
| "shiny not found" | Run install.bat |
| "Can't find soar_world" | Copy your app to soar_world/ folder |
| Multiple library paths | Fix Rprofile.site (see QUICK_FIX.md) |
| Packages won't install | Check internet, verify Rprofile.site |
| App won't start | Run diagnose.bat, check ShinyApp.log |

## 💡 Tips

1. **Always run diagnose.bat first** when troubleshooting
2. **Check ShinyApp.log** for detailed error messages
3. **Test on a clean machine** before distributing
4. **Use install.bat** instead of manual installation
5. **Keep a backup** of working R Portable folder

## 📞 Getting Help

When asking for help, provide:
- Output from diagnose.bat
- Contents of ShinyApp.log
- Contents of R-Portable/etc/Rprofile.site
- Your Windows version
- Output from: `R-Portable\bin\Rscript.exe -e ".libPaths()"`

## ✅ Success Checklist

Before distribution, verify:
- [ ] diagnose.bat shows all checks passing
- [ ] run.bat launches app successfully
- [ ] App works on machine without R installed
- [ ] ShinyApp.log shows no errors
- [ ] README_FOR_USERS.txt included
- [ ] All app files in soar_world/ folder
- [ ] Tested all major features

## 🎉 You're Done When...

1. run.bat opens your app in browser
2. App runs without errors
3. Works on a computer without R installed
4. Package size is reasonable (< 2GB)
5. You can zip it up and share it

---

**Quick Commands:**

```bash
# Diagnose issues
diagnose.bat

# Install packages
install.bat

# Run app
run.bat

# Check Shiny installed
R-Portable\bin\Rscript.exe -e "library(shiny)"

# Check library path
R-Portable\bin\Rscript.exe -e ".libPaths()"
```

**Need help RIGHT NOW?** → Read **QUICK_FIX.md**
