# QUICK START: Fixing "Error: object 'shiny' not found"

## The Problem
You ran `run.bat` and got this error in ShinyApp.log:
```
Error: object 'shiny' not found
```

This means Shiny is not installed in your R Portable.

## The Solution (3 Steps)

### Step 1: Run the Diagnostic (30 seconds)
1. Double-click `diagnose.bat`
2. Look at the output - it will tell you what's wrong
3. Press any key when done

### Step 2: Install Packages (2-5 minutes)
1. Double-click `install.bat`
2. Wait for it to finish (don't close the window!)
3. Look for "✓ Installation Complete!" message
4. Press any key when done

### Step 3: Test Your App
1. Double-click `run.bat`
2. Your app should now open in the browser

## If Step 2 Fails

If the installation fails, you need to check your Rprofile.site file:

### Check Rprofile.site:
1. Go to folder: `R-Portable\etc\`
2. Look for file: `Rprofile.site`
3. If it doesn't exist, create it
4. Open it in Notepad
5. Make sure it contains ONLY this line:
   ```
   .libPaths(.Library)
   ```
6. Save and close
7. Try Step 2 again (double-click `install.bat`)

## Manual Installation (If All Else Fails)

If the automated installer doesn't work:

1. Double-click: `R-Portable\bin\R.exe`
2. In the R window, type this and press Enter:
   ```r
   install.packages('shiny')
   ```
3. Wait for it to finish
4. Type this and press Enter:
   ```r
   library(shiny)
   ```
5. If you see "Loading required package: methods" or similar, it worked!
6. Close R by typing: `q()` and pressing Enter
7. Select "n" (no) when asked to save workspace
8. Try running your app again

## Still Not Working?

See the full troubleshooting guide: `TROUBLESHOOTING.md`

## File Structure Reference

Make sure your folder looks like this:
```
YourFolder/
├── R-Portable/          (R installation)
│   ├── bin/
│   ├── etc/
│   │   └── Rprofile.site  ← Check this file!
│   └── library/           ← Packages go here
├── soar_world/          (Your app)
├── runShinyApp.R
├── run.bat              ← Run this to start app
├── diagnose.bat         ← Run this to check setup
├── install.bat          ← Run this to install packages
└── diagnose_setup.R
```

## Common Mistakes

❌ **Mistake:** Running R-Portable\bin\R.exe before setting up Rprofile.site
✅ **Fix:** Create Rprofile.site first, THEN install packages

❌ **Mistake:** Having R installed on your system and packages went there
✅ **Fix:** Make sure Rprofile.site exists with correct content

❌ **Mistake:** Missing the soar_world folder
✅ **Fix:** Copy your app files to soar_world/ folder

❌ **Mistake:** Antivirus blocking installation
✅ **Fix:** Temporarily disable antivirus or add folder to exceptions

## Quick Command Reference

**See if Shiny is installed:**
```
R-Portable\bin\Rscript.exe -e "library(shiny)"
```

**Check where packages install:**
```
R-Portable\bin\Rscript.exe -e ".libPaths()"
```
(Should show only ONE path - to R-Portable\library)

**Install a specific package:**
```
R-Portable\bin\Rscript.exe -e "install.packages('packagename')"
```

---

**Most common cause:** Rprofile.site is missing or incorrect.
**Most common fix:** Create/fix Rprofile.site, then run install.bat
